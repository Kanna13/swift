import Darwin

let user = readLine()!
var empryArr: [String] = []
var makeArr = Array(user)
for i in makeArr{
    let makeString = String(i)
    empryArr.append(makeString)
}
let digits = empryArr.compactMap{Int(String($0))}
var firstsecondcollection = empryArr[0] + empryArr[1]
var toAnswer: [Int] = []
var secondCollection = empryArr[2] + empryArr[3]
var c1 = 0
var c2 = 0
var tofinder = 0
func main(number1: Int){
    for i in 1...9{
        var myItem = i
        myItem *= myItem
        
        if myItem <= number1{
            c1 += 1
            toAnswer.append(c1)
            tofinder = myItem
        }
      }
}
main(number1: Int(firstsecondcollection)!)
let firstAnswer = Int(toAnswer.max()!)
var firstFinder = Int(firstsecondcollection)! % tofinder
var otherFInder = String(firstFinder) + secondCollection
var finalResult: [Int] = []
func findFinalPart(number:Int) {
    for i in 1...9{
        let answer = firstAnswer * 2
        let newVission = String(answer) + String(i)
        if Int(newVission)! * i == Int(otherFInder)!{
            finalResult.append(i)
        }
    }
}
findFinalPart(number: firstAnswer)
let answerFinal = finalResult.max()!
let answer = String(firstAnswer) + String(answerFinal)
print(answer)
print(sqrt(4096.0))
