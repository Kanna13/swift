
//var salary = 7500
//
//var expenditure = 2500
//
//var oneMonth = 0
//
//var allTime = 0
//
//for i in 1...12{
//    oneMonth = salary - expenditure
//    allTime += oneMonth
//}
//
//print("Per month: \(oneMonth)")
//print("Per year: \(allTime)")
//




//var counter = 0
//let user = readLine()!
//while true{
//
//    let randomNumber = Int.random(in: 0...100)
//    if Int(user)! != randomNumber{
//        counter += 1
//    }
//    else{
//        print("You win!, number was \(randomNumber). Your attempts \(counter)")
//        break
//    }
//}




let myDict: [String:Int] = ["1":2, "2":5, "3":5, "4":4, "5":5, "6":6, "7":3, "8":7, "9":6, "0":6]
var emptyArray = Array<Int>()
let user: String = readLine()!
let arr = user.map { String($0) }
for i in myDict{
    for k in arr{
        if i.key == k{
            emptyArray.append(i.value)
        }
    }
}
print(emptyArray.reduce(0, +))
