func calcuator(num1:Int, num2:Int, symbol:String){
    if(symbol == "+"){
        print(num1 + num2)
    }
    else if(symbol == "-"){
        print(num1 - num2)
    }
    else if(symbol == "*"){
        print(num1 * num2);
    }
    else if(symbol == "/" && num2 != 0){
        print(num1 / num2)
    }
    else if(symbol == "/" && num2 == 0){
        print("Sorry, Zero Divizion Error!")
    }
    else if(symbol == "%" && num2 != 0){
        print(num1 % num2)
    }
    else{
        print("Sorry, Zero Divizion Error! ")
    }
}

let firstNum1 = readLine()
let secondNum1 = readLine()
print("Please choose one of them: +   -  /  %")
let symbol = readLine()


calcuator(num1: (Int(firstNum1!)!), num2: (Int(secondNum1!)!), symbol: (symbol ?? "none"))

